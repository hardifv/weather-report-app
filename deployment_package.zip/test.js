const { S3Client, ListObjectsV2Command, GetObjectCommand } = require('@aws-sdk/client-s3');

// Function to read the content from a readable stream and return it as a string
async function streamToString(stream) {
    const chunks = [];
    for await (const chunk of stream) {
        chunks.push(chunk);
    }
    return Buffer.concat(chunks).toString('utf-8');
}

info = async (event, context) => {
    try {
        // Initialize the S3 client
        const s3Client = new S3Client({ region: 'us-east-1' }); // Replace 'us-east-1' with your desired region

        // List all objects in the bucket
        const bucketName = 'weather-report-florida-app'; // Replace 'your-bucket-name' with your actual bucket name
        const listObjectsParams = { Bucket: bucketName };
        const listObjectsCommand = new ListObjectsV2Command(listObjectsParams);
        const Contents = await s3Client.send(listObjectsCommand);

        // Iterate over the list of objects
        for (const object of Contents) {
            const objectKey = object.Key;

            // Retrieve the object from S3
            const getObjectParams = { Bucket: bucketName, Key: objectKey };
            const getObjectCommand = new GetObjectCommand(getObjectParams);
            const { Body } = await s3Client.send(getObjectCommand);

            // Convert the response body from a stream to a string
            const fileContentString = await streamToString(Body);

            // Parse the JSON content
            const jsonData = JSON.parse(fileContentString);
            
            // Access specific fields from the JSON data
            const locationName = jsonData.location.name;
            const temperatureCelsius = jsonData.current.temp_c;
            const temperatureFahrenheit = jsonData.current.temp_f;
            
            // Log the retrieved data
            console.log(`Location: ${locationName}, Temperature (C): ${temperatureCelsius}, Temperature (F): ${temperatureFahrenheit}`);

            // Your existing code to process the file...
        }

    } catch (error) {
        console.error('Error:', error);
        return { statusCode: 500, body: JSON.stringify({ message: 'An error occurred while processing the files', error: error }) };
    }
};


info()